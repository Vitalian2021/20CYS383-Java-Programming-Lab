package com.amrita.jpl.cys21006.endsem;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

// com.amrita.jpl.cys21006.endsem.File class
class File {
    private String fileName;
    private int fileSize;

    public File(String fileName, int fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getFileSize() {
        return fileSize;
    }

    public void setFileSize(int fileSize) {
        this.fileSize = fileSize;
    }

    public void displayFileDetails() {
        System.out.println("com.amrita.jpl.cys21006.endsem.File Name: " + fileName + ", com.amrita.jpl.cys21006.endsem.File Size: " + fileSize);
    }
}

// com.amrita.jpl.cys21006.endsem.Document class
class Document extends File {
    private String documentType;

    public Document(String fileName, int fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("com.amrita.jpl.cys21006.endsem.Document Type: " + documentType);
    }
}

// com.amrita.jpl.cys21006.endsem.Image class
class Image extends File {
    private String resolution;

    public Image(String fileName, int fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Resolution: " + resolution);
    }
}

// com.amrita.jpl.cys21006.endsem.Video class
class Video extends File {
    private String duration;

    public Video(String fileName, int fileSize, String duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Duration: " + duration);
    }
}

// com.amrita.jpl.cys21006.endsem.FileManager interface
interface FileManager {
    void addFile(File file);
    void deleteFile(String fileName);
    ArrayList<File> getFiles();
}

// com.amrita.jpl.cys21006.endsem.FileManagerImpl class
class FileManagerImpl implements FileManager {
    private ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    public void addFile(File file) {
        files.add(file);
    }

    public void deleteFile(String fileName) {
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).getFileName().equals(fileName)) {
                files.remove(i);
                break;
            }
        }
    }

    public ArrayList<File> getFiles() {
        return files;
    }
}

// com.amrita.jpl.cys21006.endsem.FileManagementSystemUI class
class FileManagementSystemUI {
    private FileManager fileManager;
    private JFrame frame;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField fileNameTextField, fileSizeTextField;
    private JComboBox<String> fileTypeComboBox;

    public FileManagementSystemUI() {
        fileManager = new FileManagerImpl();
        createUI();
    }

    private void createUI() {
        frame = new JFrame("com.amrita.jpl.cys21006.endsem.File Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // com.amrita.jpl.cys21006.endsem.File details panel
        JPanel fileDetailsPanel = new JPanel();
        fileDetailsPanel.setLayout(new BoxLayout(fileDetailsPanel, BoxLayout.Y_AXIS));

        JPanel fileNamePanel = new JPanel();
        JLabel fileNameLabel = new JLabel("com.amrita.jpl.cys21006.endsem.File Name:");
        fileNameTextField = new JTextField(20);
        fileNamePanel.add(fileNameLabel);
        fileNamePanel.add(fileNameTextField);

        JPanel fileSizePanel = new JPanel();
        JLabel fileSizeLabel = new JLabel("com.amrita.jpl.cys21006.endsem.File Size:");
        fileSizeTextField = new JTextField(10);
        fileSizePanel.add(fileSizeLabel);
        fileSizePanel.add(fileSizeTextField);

        JPanel fileTypePanel = new JPanel();
        JLabel fileTypeLabel = new JLabel("com.amrita.jpl.cys21006.endsem.File Type:");
        String[] fileTypes = {"com.amrita.jpl.cys21006.endsem.Document", "com.amrita.jpl.cys21006.endsem.Image", "com.amrita.jpl.cys21006.endsem.Video"};
        fileTypeComboBox = new JComboBox<>(fileTypes);
        fileTypePanel.add(fileTypeLabel);
        fileTypePanel.add(fileTypeComboBox);

        fileDetailsPanel.add(fileNamePanel);
        fileDetailsPanel.add(fileSizePanel);
        fileDetailsPanel.add(fileTypePanel);

        // Button panel
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add com.amrita.jpl.cys21006.endsem.File");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addFileButtonClicked();
            }
        });
        JButton deleteButton = new JButton("Delete com.amrita.jpl.cys21006.endsem.File");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteFileButtonClicked();
            }
        });
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                refreshButtonClicked();
            }
        });
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);

        // Table
        table = new JTable();
        tableModel = new DefaultTableModel();
        table.setModel(tableModel);
        tableModel.addColumn("com.amrita.jpl.cys21006.endsem.File Name");
        tableModel.addColumn("com.amrita.jpl.cys21006.endsem.File Size");
        tableModel.addColumn("com.amrita.jpl.cys21006.endsem.File Type");

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(fileDetailsPanel, BorderLayout.NORTH);
        mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        frame.getContentPane().add(mainPanel);
        frame.pack();
        frame.setVisible(true);
    }

    private void addFileButtonClicked() {
        String fileName = fileNameTextField.getText();
        int fileSize = Integer.parseInt(fileSizeTextField.getText());
        String fileType = (String) fileTypeComboBox.getSelectedItem();

        if (fileType.equals("com.amrita.jpl.cys21006.endsem.Document")) {
            String documentType = JOptionPane.showInputDialog(frame, "Enter com.amrita.jpl.cys21006.endsem.Document Type:");
            if (documentType != null && !documentType.isEmpty()) {
                Document document = new Document(fileName, fileSize, documentType);
                fileManager.addFile(document);
                tableModel.addRow(new Object[]{fileName, fileSize, "com.amrita.jpl.cys21006.endsem.Document"});
                clearFields();
            }
        } else if (fileType.equals("com.amrita.jpl.cys21006.endsem.Image")) {
            String resolution = JOptionPane.showInputDialog(frame, "Enter Resolution:");
            if (resolution != null && !resolution.isEmpty()) {
                Image image = new Image(fileName, fileSize, resolution);
                fileManager.addFile(image);
                tableModel.addRow(new Object[]{fileName, fileSize, "com.amrita.jpl.cys21006.endsem.Image"});
                clearFields();
            }
        } else if (fileType.equals("com.amrita.jpl.cys21006.endsem.Video")) {
            String duration = JOptionPane.showInputDialog(frame, "Enter Duration:");
            if (duration != null && !duration.isEmpty()) {
                Video video = new Video(fileName, fileSize, duration);
                fileManager.addFile(video);
                tableModel.addRow(new Object[]{fileName, fileSize, "com.amrita.jpl.cys21006.endsem.Video"});
                clearFields();
            }
        }
    }

    private void deleteFileButtonClicked() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            String fileName = (String) table.getValueAt(selectedRow, 0);
            fileManager.deleteFile(fileName);
            tableModel.removeRow(selectedRow);
        } else {
            JOptionPane.showMessageDialog(frame, "Please select a file to delete.");
        }
    }

    private void refreshButtonClicked() {
        clearTable();
        ArrayList<File> files = fileManager.getFiles();
        for (File file : files) {
            if (file instanceof Document) {
                Document document = (Document) file;
                tableModel.addRow(new Object[]{document.getFileName(), document.getFileSize(), "com.amrita.jpl.cys21006.endsem.Document"});
            } else if (file instanceof Image) {
                Image image = (Image) file;
                tableModel.addRow(new Object[]{image.getFileName(), image.getFileSize(), "com.amrita.jpl.cys21006.endsem.Image"});
            } else if (file instanceof Video) {
                Video video = (Video) file;
                tableModel.addRow(new Object[]{video.getFileName(), video.getFileSize(), "com.amrita.jpl.cys21006.endsem.Video"});
            }
        }
    }

    private void clearFields() {
        fileNameTextField.setText("");
        fileSizeTextField.setText("");
        fileTypeComboBox.setSelectedIndex(0);
    }

    private void clearTable() {
        tableModel.setRowCount(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FileManagementSystemUI();
            }
        });
    }
}