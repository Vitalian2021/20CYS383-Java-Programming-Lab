import java.io.File;
import java.util.ArrayList;

interface FileManager {
    void addFile(Video file);
    void deleteFile(String fileName);
    ArrayList<File> getFiles();
}
