import java.io.File;
import java.util.ArrayList;

class FileManagerImpl implements FileManager {
    private ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    public void addFile(Video file) {
        files.add(file);
    }

    public void deleteFile(String fileName) {
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).getName().equals(fileName)) {
                files.remove(i);
                break;
            }
        }
    }

    public ArrayList<File> getFiles() {
        return files;
    }
}
