import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.*;
import java.io.File;

abstract class Document extends File {
    private String documentType;

    public Document(String fileName, int fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Document Type: " + documentType);
    }

    public abstract int getLength();

    public abstract void addDocumentListener(DocumentListener listener);

    public abstract void removeDocumentListener(DocumentListener listener);

    public abstract void addUndoableEditListener(UndoableEditListener listener);

    public abstract void removeUndoableEditListener(UndoableEditListener listener);

    public abstract Object getProperty(Object key);

    public abstract void putProperty(Object key, Object value);

    public abstract void remove(int offs, int len) throws BadLocationException;

    public abstract void insertString(int offset, String str, AttributeSet a) throws BadLocationException;

    public abstract String getText(int offset, int length) throws BadLocationException;

    public abstract void getText(int offset, int length, Segment txt) throws BadLocationException;

    public abstract Position getStartPosition();

    public abstract Position getEndPosition();

    public abstract Position createPosition(int offs) throws BadLocationException;

    public abstract Element[] getRootElements();

    public abstract Element getDefaultRootElement();

    public abstract void render(Runnable r);
}
