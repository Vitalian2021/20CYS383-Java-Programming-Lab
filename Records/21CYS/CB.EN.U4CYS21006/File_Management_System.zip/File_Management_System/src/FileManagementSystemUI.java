import javax.swing.*;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.File;
import java.util.ArrayList;

class FileManagementSystemUI {
    private final FileManager fileManager;
    private JFrame frame;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField fileNameTextField, fileSizeTextField;
    private JComboBox<String> fileTypeComboBox;

    public FileManagementSystemUI() {
        fileManager = new FileManagerImpl();
        createUI();
    }

    private void createUI() {
        frame = new JFrame("File Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // File details panel
        JPanel fileDetailsPanel = new JPanel();
        fileDetailsPanel.setLayout(new BoxLayout(fileDetailsPanel, BoxLayout.Y_AXIS));

        JPanel fileNamePanel = new JPanel();
        JLabel fileNameLabel = new JLabel("File Name:");
        fileNameTextField = new JTextField(20);
        fileNamePanel.add(fileNameLabel);
        fileNamePanel.add(fileNameTextField);

        JPanel fileSizePanel = new JPanel();
        JLabel fileSizeLabel = new JLabel("File Size:");
        fileSizeTextField = new JTextField(10);
        fileSizePanel.add(fileSizeLabel);
        fileSizePanel.add(fileSizeTextField);

        JPanel fileTypePanel = new JPanel();
        JLabel fileTypeLabel = new JLabel("File Type:");
        String[] fileTypes = {"Document", "Image", "Video"};
        fileTypeComboBox = new JComboBox<>(fileTypes);
        fileTypePanel.add(fileTypeLabel);
        fileTypePanel.add(fileTypeComboBox);

        fileDetailsPanel.add(fileNamePanel);
        fileDetailsPanel.add(fileSizePanel);
        fileDetailsPanel.add(fileTypePanel);

        // Button panel
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add File");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addFileButtonClicked();
            }
        });
        JButton deleteButton = new JButton("Delete File");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteFileButtonClicked();
            }
        });
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                refreshButtonClicked();
            }
        });
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);

        // Table
        table = new JTable();
        tableModel = new DefaultTableModel();
        table.setModel(tableModel);
        tableModel.addColumn("File Name");
        tableModel.addColumn("File Size");
        tableModel.addColumn("File Type");

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(fileDetailsPanel, BorderLayout.NORTH);
        mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        frame.getContentPane().add(mainPanel);
        frame.pack();
        frame.setVisible(true);
    }

    private void addFileButtonClicked() {
        String fileName = fileNameTextField.getText();
        int fileSize = Integer.parseInt(fileSizeTextField.getText());
        String fileType = (String) fileTypeComboBox.getSelectedItem();

        if (fileType.equals("Document")) {
            String documentType = JOptionPane.showInputDialog(frame, "Enter Document Type:");
            if (documentType != null && !documentType.isEmpty()) {
                Document document = new Document() {
                    @Override
                    public int getLength() {
                        return 0;
                    }

                    @Override
                    public void addDocumentListener(DocumentListener listener) {

                    }

                    @Override
                    public void removeDocumentListener(DocumentListener listener) {

                    }

                    @Override
                    public void addUndoableEditListener(UndoableEditListener listener) {

                    }

                    @Override
                    public void removeUndoableEditListener(UndoableEditListener listener) {

                    }

                    @Override
                    public Object getProperty(Object key) {
                        return null;
                    }

                    @Override
                    public void putProperty(Object key, Object value) {

                    }

                    @Override
                    public void remove(int offs, int len) throws BadLocationException {

                    }

                    @Override
                    public void insertString(int offset, String str, AttributeSet a) throws BadLocationException {

                    }

                    @Override
                    public String getText(int offset, int length) throws BadLocationException {
                        return null;
                    }

                    @Override
                    public void getText(int offset, int length, Segment txt) throws BadLocationException {

                    }

                    @Override
                    public Position getStartPosition() {
                        return null;
                    }

                    @Override
                    public Position getEndPosition() {
                        return null;
                    }

                    @Override
                    public Position createPosition(int offs) throws BadLocationException {
                        return null;
                    }

                    @Override
                    public Element[] getRootElements() {
                        return new Element[0];
                    }

                    @Override
                    public Element getDefaultRootElement() {
                        return null;
                    }

                    @Override
                    public void render(Runnable r) {

                    }
                };
                Object fileTypeComboBxoxdocument = null;
                fileManager.addFile((Video) null);
                tableModel.addRow(new Object[]{fileName, fileSize, "Document"});
                clearFields();
            }
        } else if (fileType.equals("Image")) {
            String resolution = JOptionPane.showInputDialog(frame, "Enter Resolution:");
            if (resolution != null && !resolution.isEmpty()) {
                Image image = new Image() {
                    @Override
                    public int getWidth(ImageObserver observer) {
                        return 0;
                    }

                    @Override
                    public int getHeight(ImageObserver observer) {
                        return 0;
                    }

                    @Override
                    public ImageProducer getSource() {
                        return null;
                    }

                    @Override
                    public Graphics getGraphics() {
                        return null;
                    }

                    @Override
                    public Object getProperty(String name, ImageObserver observer) {
                        return null;
                    }
                };
                fileManager.addFile(image);
                tableModel.addRow(new Object[]{fileName, fileSize, "Image"});
                clearFields();
            }
        } else if (fileType.equals("Video")) {
            String duration = JOptionPane.showInputDialog(frame, "Enter Duration:");
            if (duration != null && !duration.isEmpty()) {
                Video video = new Video(fileName, fileSize, duration);
                fileManager.addFile(video);
                tableModel.addRow(new Object[]{fileName, fileSize, "Video"});
                clearFields();
            }
        }
    }

    private void deleteFileButtonClicked() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            String fileName = (String) table.getValueAt(selectedRow, 0);
            fileManager.deleteFile(fileName);
            tableModel.removeRow(selectedRow);
        } else {
            JOptionPane.showMessageDialog(frame, "Please select a file to delete.");
        }
    }

    private void refreshButtonClicked() {
        clearTable();
        ArrayList<File> files = fileManager.getFiles();
        for (File file : files) {
            if (file instanceof Document document)
                tableModel.addRow(new Object[]{document.getLength(), document.getClass(), "Document"});
            else if (file instanceof Video video) {
                tableModel.addRow(new Object[]{video.getLength(), video.getClass(), "Video"});
            }
        }
    }

    private void clearFields() {
        fileNameTextField.setText("");
        fileSizeTextField.setText("");
        fileTypeComboBox.setSelectedIndex(0);
    }

    private void clearTable() {
        tableModel.setRowCount(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FileManagementSystemUI();
            }
        });
    }
}
