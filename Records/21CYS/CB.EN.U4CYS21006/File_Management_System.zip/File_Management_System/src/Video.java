import java.io.File;

class Video extends File {
    private String duration;

    public Video(String fileName, int fileSize, String duration) {
        super(fileName, String.valueOf(fileSize));
        this.duration = duration;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public void displayFileDetails() {
        super.listFiles();
        System.out.println("Duration: " + duration);
    }

    public Object getLength() {
        return null;
    }
}